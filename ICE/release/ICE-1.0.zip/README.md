**ICE** is a Java module which helps you to build non-blocking I/O message based servers.

lambdaprime <id.blackmesa@gmail.com>

# Requirements

Java 11

# Download

You can download **ICE** from <https://github.com/lambdaprime/ICE/releases>

# Documentation

Javadoc is available here <http://portal2.atwebpages.com/ICE>
