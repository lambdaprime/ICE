**ICE** is a Java module which helps you to build non-blocking I/O message based servers.

lambdaprime <intid@protonmail.com>

# Requirements

Java 11

# Download

You can download **ICE** from <https://github.com/lambdaprime/ICE/releases>

Or you can add dependency to it as follows:

Gradle:

```
dependencies {
    compile 'io.github.lambdaprime:ICE:1.0'
}
```

# Documentation

Javadoc is available here <http://portal2.atwebpages.com/ICE>
